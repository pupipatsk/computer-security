<?php

if (isset($_POST['Upload'])) {
	// Where are we going to be writing to?
	$target_path = DVWA_WEB_PAGE_TO_ROOT . "hackable/uploads/";

	// FIX: Validate file type and size
	$uploaded_name = $_FILES['uploaded']['name'];
	$uploaded_ext = substr($uploaded_name, strrpos($uploaded_name, '.') + 1);
	$uploaded_size = $_FILES['uploaded']['size'];
	$uploaded_type = $_FILES['uploaded']['type'];
	$uploaded_tmp = $_FILES['uploaded']['tmp_name'];

	// FIX: Rename file to prevent overwriting and execution
	$target_file = md5(uniqid() . $uploaded_name) . '.' . $uploaded_ext;
	$target_path .= $target_file;

	if (
		(strtolower($uploaded_ext) == 'jpg' || strtolower($uploaded_ext) == 'jpeg' || strtolower($uploaded_ext) == 'png') &&
		($uploaded_size < 100000) &&
		($uploaded_type == 'image/jpeg' || $uploaded_type == 'image/png') &&
		getimagesize($uploaded_tmp)
	) {

		// Can we move the file to the upload folder?
		if (move_uploaded_file($uploaded_tmp, $target_path)) {
			// Yes!
			$html .= "<pre><a href='{$target_path}'>{$target_file}</a> succesfully uploaded!</pre>";
		} else {
			// No
			$html .= '<pre>Your image was not uploaded.</pre>';
		}
	} else {
		$html .= '<pre>Your image was not uploaded. We can only accept JPEG or PNG images.</pre>';
	}
}

?>