<?php

header("X-XSS-Protection: 0");

// Is there any input?
if (array_key_exists("name", $_GET) && $_GET['name'] != NULL) {
	// Feedback for end user
	// FIX: Escape output to prevent XSS
	$html .= '<pre>Hello ' . htmlspecialchars($_GET['name']) . '</pre>';
}

?>