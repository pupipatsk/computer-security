<?php

if (isset($_POST['btnSign'])) {
	// Get input
	$message = trim($_POST['mtxMessage']);
	$name = trim($_POST['txtName']);

	// Sanitize message input
	$message = stripslashes($message);
	// FIX: Sanitize input to prevent Stored XSS
	$message = htmlspecialchars($message);

	// Sanitize name input
	$name = stripslashes($name);
	// FIX: Sanitize input to prevent Stored XSS
	$name = htmlspecialchars($name);

	// Update database
	// FIX: Use prepared statements
	$query = "INSERT INTO guestbook ( comment, name ) VALUES ( ?, ? )";

	if ($stmt = mysqli_prepare($GLOBALS["___mysqli_ston"], $query)) {
		mysqli_stmt_bind_param($stmt, "ss", $message, $name);
		mysqli_stmt_execute($stmt);
		mysqli_stmt_close($stmt);
	}
}

?>