<?php

if( isset( $_GET[ 'Login' ] ) ) {
	// Get username
	$user = $_GET[ 'username' ];

	// Get password
	$pass = $_GET[ 'password' ];
	$pass = md5( $pass );

	// Check the database
	$query  = "SELECT * FROM `users` WHERE user = ? AND password = ?";
	
	if ($stmt = mysqli_prepare($GLOBALS["___mysqli_ston"], $query)) {
		mysqli_stmt_bind_param($stmt, "ss", $user, $pass);
		mysqli_stmt_execute($stmt);
		mysqli_stmt_store_result($stmt);

		if( mysqli_stmt_num_rows( $stmt ) == 1 ) {
			// Get users details
			// Binding result variables
			mysqli_stmt_bind_result($stmt, $user_id, $first_name, $last_name, $user_name, $password, $avatar, $last_login, $failed_login);
			mysqli_stmt_fetch($stmt);

			// Login successful
			$html .= "<p>Welcome to the password protected area " . htmlspecialchars($user) . "</p>";
			$html .= "<img src=\"{$avatar}\" />";
		}
		else {
			// Login failed
			sleep(2); // Anti-brute force
			$html .= "<pre><br />Username and/or password incorrect.</pre>";
		}
		mysqli_stmt_close($stmt);
	}

	((is_null($___mysqli_res = mysqli_close($GLOBALS["___mysqli_ston"]))) ? false : $___mysqli_res);
}

?>
